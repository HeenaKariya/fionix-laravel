<?php $__env->startSection('title', 'Challans'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Challans for <?php echo e($project->name); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Challan List</h3>
            <?php if(Auth::user()->hasRole('manager') || Auth::user()->hasRole('supervisor')): ?>
                <a href="<?php echo e(route('projects.challans.create', $project->id)); ?>" class="btn btn-primary float-right create-btn">Create Challan</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="GET" id="dateFilterForm">
                <div class="row align-items-end">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="start_date">Start Date</label>
                            <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e($startDate); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="end_date">End Date</label>
                            <input type="date" name="end_date" class="form-control" value="<?php echo e(old('end_date', \Carbon\Carbon::parse($endDate)->format('Y-m-d'))); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group d-flex justify-content-start align-items-end">
                            <button type="submit" class="btn small-width-view">Filter</button>
                        </div>
                    </div>
                </div>
            </form>
            <div id="table-view1">
                <table class="table table-bordered" id="challans-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Bill Date</th>
                            <th>Amount</th>
                            <th>Payment Type</th>
                            <th>Expense Category</th>
                            <th>Status</th>
                            <th>Created By</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $challans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($challan->bill_date)->format('d M Y')); ?></td>
                                <td><?php echo e($challan->amount); ?></td>
                                <td><?php echo e($challan->payment_type); ?></td>
                                <td><?php echo e($challan->expense_category); ?></td>
                                <td>
                                    <?php
                                        $statusClass = '';
                                        if ($challan->status === 'approved') {
                                            $statusClass = 'bg-success text-white';
                                        } elseif ($challan->status === 'rejected') {
                                            $statusClass = 'bg-danger text-white';
                                        }
                                    ?>
                                    <span class="label <?php echo e($statusClass); ?>"><?php echo e(ucfirst($challan->status)); ?></span>
                                </td>
                                <td><?php echo e($challan->user->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('projects.challans.show', [$project->id, $challan->id])); ?>" class="btn btn-sm btn-primary full-width-view">View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div id="list-view1" class="d-none">
                <ul class="list-group" id="challans-list"></ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
            var table = $('#challans-table').DataTable({
                responsive: {
                    details: {
                        display: $.fn.dataTable.Responsive.display.childRowImmediate,
                        type: 'inline',
                        }
                },
                autoWidth: false,
                order: [[0, 'desc']],
        });

        table.rows().every(function(rowIdx, tableLoop, rowLoop) {
                var row = this;
                if (!row.child.isShown()) {
                    row.child.show();
                    $(row.node()).addClass('shown');  
                }
            });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects-new\concord-laravel\resources\views/challans/index.blade.php ENDPATH**/ ?>