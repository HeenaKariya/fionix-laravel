<?php $__env->startSection('title', 'Money Out List'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Money Out List</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('money_out.index')); ?>">
                <div class="row align-items-end">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="start_date">Start Date</label>
                            <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e($startDate); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="end_date">End Date</label>
                            <input type="date" name="end_date" class="form-control" value="<?php echo e(old('end_date', \Carbon\Carbon::parse($endDate)->format('Y-m-d'))); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group d-flex justify-content-start align-items-end">
                            <button type="submit" class="btn small-width-view">Filter</button>
                        </div>
                    </div>
                </div>
            </form>
            <table id="moneyOutTable" class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Project</th>
                        <th>Name</th>
                        <th>Transaction ID</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Payment Type</th>
                        <th>Payment Date</th>
                        <th>Amount</th>
                        <th>Image/Document</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $moneyOutData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneyOut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($moneyOut->id); ?></td>
                            <td><?php echo e($moneyOut->project->name); ?></td>
                            <td><?php echo e($moneyOut->user->name); ?></td>
                            <td><?php echo e($moneyOut->transaction_id); ?></td>
                            <td><?php echo e($moneyOut->from); ?></td>
                            <td><?php echo e($moneyOut->to); ?></td>
                            <td><?php echo e($moneyOut->payment_type); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($moneyOut->payment_datetime)->format('h:i A d/m/Y')); ?></td>
                            <td><?php echo e(number_format($moneyOut->amount, 2)); ?></td>
                            <td>
                                <?php if($moneyOut->image): ?>
                                    <?php $__currentLoopData = json_decode($moneyOut->image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span><?php echo e($loop->iteration); ?>. <?php echo e(strlen(basename($file)) > 5 ? substr(basename($file), 0, 5) . '...' : basename($file)); ?>

                                            </span>
                                            <div>
                                                <a href="#" class="btn create-btn btn-sm view-file" data-file="<?php echo e(asset('storage/' . $file)); ?>" data-filename="<?php echo e(basename($file)); ?>">View</a>
                                                <a href="<?php echo e(asset('storage/' . $file)); ?>" class="btn create-btn btn-sm" download>Download</a>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    No files
                                <?php endif; ?>
                            </td>

                            <td><?php echo e($moneyOut->notes); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal for Viewing Files -->
<div class="modal fade" id="viewFileModal" tabindex="-1" role="dialog" aria-labelledby="viewFileModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewFileModalLabel">View File</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center">
                <iframe id="fileViewer" src="" style="width:100%;height:600px;" frameborder="0"></iframe>
                <img id="imageViewer" src="" style="max-width:100%; max-height:600px;" />
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css"> -->
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script> -->

    <script>
        $(document).ready(function() {
            var table = $('#moneyOutTable').DataTable({
                responsive: {
                    details: {
                        display: $.fn.dataTable.Responsive.display.childRowImmediate,
                        type: 'inline',
                        }
                },
                autoWidth: false,
        });

        table.rows().every(function(rowIdx, tableLoop, rowLoop) {
            var row = this;
            if (!row.child.isShown()) {
                row.child.show();
                $(row.node()).addClass('shown');  
            }
        });

            // Handle file view
        $(document).on('click', '.view-file', function(e) {
        e.preventDefault();
        var fileUrl = $(this).data('file');
        var fileName = $(this).data('filename');
        var fileExtension = fileName.split('.').pop().toLowerCase();

        $('#fileViewer').hide();
        $('#imageViewer').hide();

        if (fileExtension === 'pdf') {
            $('#fileViewer').attr('src', fileUrl).show();
        } else if (['jpg', 'jpeg', 'png', 'gif'].includes(fileExtension)) {
            $('#imageViewer').attr('src', fileUrl).show();
        }

        $('#viewFileModalLabel').text(fileName); // Set the modal title to the file name
        $('#viewFileModal').modal('show');
    });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects-new\concord-laravel\resources\views/money_out/money_out_list.blade.php ENDPATH**/ ?>