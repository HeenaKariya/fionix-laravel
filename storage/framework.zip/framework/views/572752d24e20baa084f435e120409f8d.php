<?php $__env->startSection('title', 'Money In List'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Money In List</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-body">
            
            <form method="GET" action="<?php echo e(route('money_in.index')); ?>">
                <div class="row align-items-end">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="start_date">Start Date</label>
                            <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e($startDate); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="end_date">End Date</label>
                            <input type="date" name="end_date" class="form-control" value="<?php echo e(old('end_date', \Carbon\Carbon::parse($endDate)->format('Y-m-d'))); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group d-flex justify-content-start align-items-end">
                            <button type="submit" class="btn small-width-view">Filter</button>
                        </div>
                    </div>
                </div>
            </form>

            <table id="moneyInTable" class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Project</th>
                        <th>Name</th>
                        <th>Transaction ID</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Payment Type</th>
                        <th>Payment Date and Time</th>
                        <th>Amount</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $moneyInData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moneyIn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($moneyIn->id); ?></td>
                            <td><?php echo e($moneyIn->project->name); ?></td>
                            <td><?php echo e($moneyIn->user->name); ?></td>
                            <td><?php echo e($moneyIn->transaction_id); ?></td>
                            <td><?php echo e($moneyIn->from); ?></td>
                            <td><?php echo e($moneyIn->to); ?></td>
                            <td><?php echo e($moneyIn->payment_type); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($moneyIn->payment_datetime)->format('h:i A d/m/Y')); ?></td> 
                            <td><?php echo e(number_format($moneyIn->amount, 2)); ?></td>
                            <td><?php echo e($moneyIn->notes); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <!-- DataTables CSS -->
    <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css"> -->
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <!-- DataTables JS -->
    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script> -->
    <script>
        $(document).ready(function() {
            var table = $('#moneyInTable').DataTable({
                responsive: {
                    details: {
                        display: $.fn.dataTable.Responsive.display.childRowImmediate,
                        type: 'inline',
                        }
                },
                autoWidth: false,
            });

            table.rows().every(function(rowIdx, tableLoop, rowLoop) {
                var row = this;
                if (!row.child.isShown()) {
                    row.child.show();
                    $(row.node()).addClass('shown');  
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects-new\concord-laravel\resources\views/money_in/money_in_list.blade.php ENDPATH**/ ?>