<?php $__env->startSection('title', 'Create New Money Request'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Create New Money Request</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('money-requests.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="project_id">Project Site Name</label>
                    <select name="project_id" id="project_id" class="form-control" required>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="datetime-local" name="date" id="date" class="form-control" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d\TH:i')); ?>" required>
                </div>
                <div class="form-group">
                    <label for="amount">Amount</label>
                    <input type="number" name="amount" id="amount" class="form-control" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="payment_type">Payment Type</label>
                    <select name="payment_type" id="payment_type" class="form-control" required>
                        <option value="Cash">Cash</option>
                                    <option value="Cheque">Cheque</option>
                                    <option value="Bank Transfer">Bank Transfer</option>
                                    <option value="UPI">UPI</option>
                                    <option value="DD(Demand Draft)">DD(Demand Draft)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="note">Note</label>
                    <textarea name="note" id="note" class="form-control"></textarea>
                </div>
                <button type="submit" class="btn btn-primary full-width-approve">Submit Request</button>
                <?php if(Auth::user()->hasRole('supervisor')): ?>
                    <a href="<?php echo e(route('supervisor.dashboard')); ?>" class="btn btn-warning full-width-cancel">Cancel</a>
                <?php endif; ?>
                <?php if(Auth::user()->hasRole('manager')): ?>
                    <button type="button" class="btn btn-secondary mt-3 full-width-view" onclick="window.location='<?php echo e(route('manager.dashboard')); ?>'">Cancel</button>
                <?php endif; ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects-new\concord-laravel\resources\views/projects/money_requests.blade.php ENDPATH**/ ?>