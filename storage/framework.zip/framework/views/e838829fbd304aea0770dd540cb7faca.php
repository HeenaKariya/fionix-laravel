<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e($title); ?></h3>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <form method="GET" id="dateFilterForm">
                <div class="row align-items-end">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="start_date">Start Date</label>
                            <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e($startDate); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="end_date">End Date</label>
                            <input type="date" name="end_date" class="form-control" value="<?php echo e(old('end_date', \Carbon\Carbon::parse($endDate)->format('Y-m-d'))); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group d-flex justify-content-start align-items-end">
                            <button type="submit" class="btn small-width-view">Filter</button>
                        </div>
                    </div>
                </div>
            </form>
            <div id="table-view1">
                <table class="table table-bordered" id="money-requests-table">
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>Project Site Name</th>
                            <th>Name</th>
                            <th>Date</th>
                            <th>Amount</th>
                            <!-- <th>Payment Type</th> -->
                            <th>Status</th>
                            
                            <?php if(Auth::user()->hasAnyRole(['owner'])): ?>
                            <th>Manager Status</th>
                            <th>Owner Status</th>
                            <?php endif; ?>
                            <th>Created By</th>
                            <th>Note</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $moneyRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($request->id); ?></td>
                                <td><?php echo e($request->project->name); ?></td>
                                <td><?php echo e($request->user->name); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($request->date)->format('h:i A d/m/Y')); ?></td>
                                <td>₹<?php echo e(formatIndianCurrency($request->amount)); ?></td>
                                <!-- <td><?php echo e($request->payment_type); ?></td> -->
                                <td><?php echo e(ucfirst($request->status)); ?></td>
                                
                                <?php if(Auth::user()->hasAnyRole(['owner'])): ?>
                                <td><?php echo e($request->manager_status ? ucfirst($request->manager_status) : 'Pending'); ?></td>
                                <td><?php echo e($request->admin_status ? ucfirst($request->admin_status) : 'Pending'); ?></td>
                                <?php endif; ?>
                                <td><?php echo e($request->user->name); ?></td>
                                <td><?php echo e($request->note); ?></td>
                                <td>
                                    <a href="<?php echo e(route('projects.approve', $request->id)); ?>" class="btn btn-primary btn-sm full-width-view">View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div id="list-view1" class="d-none">
                <ul class="list-group" id="requests-list"></ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script>
    $(document).ready(function() {
        var table = $('#money-requests-table').DataTable({
                responsive: {
                    details: {
                        display: $.fn.dataTable.Responsive.display.childRowImmediate,
                        type: 'inline',
                        }
                },
                autoWidth: false,
                order: [[0, 'desc']],
        });

        table.rows().every(function(rowIdx, tableLoop, rowLoop) {
                var row = this;
                if (!row.child.isShown()) {
                    row.child.show();
                    $(row.node()).addClass('shown');  
                }
            });

        // Toastr configuration
        toastr.options = {
            positionClass: 'toast-bottom-right',
            hideDuration: 5000,
            timeOut: 5000,
            extendedTimeOut: 1000,
        };

        <?php if(session('success')): ?>
            toastr.success('<?php echo e(session('success')); ?>');
        <?php endif; ?>
        <?php if(session('error')): ?>
            toastr.error('<?php echo e(session('error')); ?>');
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects-new\concord-laravel\resources\views/owner/pending.blade.php ENDPATH**/ ?>