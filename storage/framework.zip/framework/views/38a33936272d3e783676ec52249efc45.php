<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e($title); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e($title); ?></h3>
            <?php if(Auth::user()->hasRole('manager') || Auth::user()->hasRole('supervisor')): ?>
                <a href="<?php echo e(route('challans.create')); ?>" class="btn btn-primary float-right create-btn">Create Challan</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <form method="GET" id="dateFilterForm">
                <div class="row align-items-end">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="start_date">Start Date</label>
                            <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e($startDate); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="end_date">End Date</label>
                            <input type="date" name="end_date" class="form-control" value="<?php echo e(old('end_date', \Carbon\Carbon::parse($endDate)->format('Y-m-d'))); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group d-flex justify-content-start align-items-end">
                            <button type="submit" class="btn small-width-view">Filter</button>
                        </div>
                    </div>
                </div>
            </form>
            <div id="table-view1">
                <table class="table table-bordered" id="challans-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Project Site Name</th>
                            <th>Type</th>
                            <th>From</th>
                            <th>Date</th>
                            
                            <th>Amount</th>
                            
                            <!-- <th>Expense Category</th> -->
                            <th>Status</th>
                            <th>File</th>
                            <?php if(!Auth::user()->hasRole('supervisor')): ?>
                            <th>Action</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $challans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($challan->id); ?></td>
                                <td><?php echo e($challan->project->name); ?></td>
                                <td><?php echo e($challan->payment_type); ?></td>
                                <td><?php echo e($challan->user->name); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($challan->bill_date)->format('d M Y')); ?></td>
                                
                                <td><?php echo e($challan->amount); ?></td>
                                
                                <!-- <td><?php echo e($challan->expense_category); ?></td> -->
                                <td>
                                    <?php
                                        $statusClass = '';
                                        if ($challan->status === 'approved') {
                                            $statusClass = 'bg-success text-white';
                                        } elseif ($challan->status === 'rejected') {
                                            $statusClass = 'bg-danger text-white';
                                        }
                                    ?>
                                    <span class="label <?php echo e($statusClass); ?>"><?php echo e(ucfirst($challan->status)); ?></span>
                                </td>
                                <td>
                                    <?php if($challan->upload_image): ?>
                                        <?php $__currentLoopData = json_decode($challan->upload_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="file-entry">
                                                <span><?php echo e(strlen(basename($file)) > 5 ? substr(basename($file), 0, 5) . '...' : basename($file)); ?></span><br>
                                                <button type="button" class="btn btn-primary btn-sm create-btn m-1" data-toggle="modal" data-target="#viewFileModal" data-file="<?php echo e(asset('storage/' . $file)); ?>">View</button>
                                                <a href="<?php echo e(asset('storage/' . $file)); ?>" class="btn btn-secondary btn-sm create-btn m-1" download>Download</a>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <?php if(!Auth::user()->hasRole('supervisor')): ?>
                                <td>
                                    <a href="<?php echo e(route('projects.challans.show', [$challan->project_id, $challan->id])); ?>" class="btn btn-sm btn-primary full-width-view">View</a>
                                </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- Modal -->
            <div class="modal fade" id="viewFileModal" tabindex="-1" role="dialog" aria-labelledby="viewFileModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="viewFileModalLabel">View File</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <iframe id="fileViewer" style="width: 100%; height: 500px;" frameborder="0"></iframe>
                        </div>
                    </div>
                </div>
            </div>
             <!-- end Modal -->   
            <div id="list-view1" class="d-none">
                <ul class="list-group" id="challans-list"></ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
            var table = $('#challans-table').DataTable({
                responsive: {
                    details: {
                        display: $.fn.dataTable.Responsive.display.childRowImmediate,
                        type: 'inline',
                        }
                },
                autoWidth: false,
                order: [[0, 'desc']],
        });

        table.rows().every(function(rowIdx, tableLoop, rowLoop) {
                var row = this;
                if (!row.child.isShown()) {
                    row.child.show();
                    $(row.node()).addClass('shown');  
                }
            });
        $('#viewFileModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Button that triggered the modal
        var fileUrl = button.data('file'); // Extract info from data-* attributes
        var modal = $(this);
        modal.find('.modal-body #fileViewer').attr('src', fileUrl);
    });
    });    
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects-new\concord-laravel\resources\views/challans/list.blade.php ENDPATH**/ ?>