<?php $__env->startSection('title', 'Projects Wise Balance'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Projects Wise Balance</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="overall-balance-card">
                <h2><?php echo e($user->name); ?></h2>
                <h1>₹<?php echo e(formatIndianCurrency($overallBalance)); ?></h1>

                <p>Overall Available Balance</p>
                <a href="<?php echo e(route('money-requests.create')); ?>" class="btn btn-secondary create-btn">Create Money Request</a>
            </div>
            <!-- <form method="GET" action="<?php echo e(route('supervisor.dashboard')); ?>">
                <div class="row align-items-end">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="start_date">Start Date</label>
                            <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e($startDate); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="end_date">End Date</label>
                            <input type="date" name="end_date" class="form-control" value="<?php echo e(old('end_date', \Carbon\Carbon::parse($endDate)->format('Y-m-d'))); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group d-flex justify-content-start align-items-end">
                            <button type="submit" class="btn small-width-view">Filter</button>
                        </div>
                    </div>
                </div>
            </form> -->
            <div class="table-responsive">
                <table id="projects-table" class="table table-bordered ">
                    <thead>
                        <tr>
                            <th>Project ID</th>
                            <th>Project Site Name</th>
                            <th>Available Balance</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($project->id); ?></td>
                                <td><?php echo e($project->name); ?></td>
                                <td>₹<?php echo e(formatIndianCurrency($project->supervisorBalance)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('projects.challans.create', $project->id)); ?>" class="btn btn-sm btn-primary full-width-view">Add Bill/Challan</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .overall-balance-card {
        text-align: center;
        margin-bottom: 2rem;
    }
    .overall-balance-card h1 {
        font-size: 3rem;
        color: #4CAF50;
    }
    .overall-balance-card p {
        font-size: 1.2rem;
        color: #666;
    }
    .list-group-item {
        margin-bottom: 1rem;
        padding: 1.5rem;
        border: 1px solid #ddd;
        border-radius: 0.5rem;
    }
    .list-group-item strong {
        display: inline-block;
        width: 150px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
   
    $(document).ready(function() {
            var table = $('#projects-table').DataTable({
                responsive: {
                    details: {
                        display: $.fn.dataTable.Responsive.display.childRowImmediate,
                        type: 'inline',
                        }
                },
                autoWidth: false,
        });

            table.rows().every(function(rowIdx, tableLoop, rowLoop) {
                var row = this;
                if (!row.child.isShown()) {
                    row.child.show();
                    $(row.node()).addClass('shown');  
                }
            });
            toastr.options = {
            positionClass: 'toast-bottom-right',
            hideDuration: 5000,
            timeOut: 5000,
            extendedTimeOut: 1000,
        };
        
        <?php if(session('success')): ?>
            toastr.success('<?php echo e(session('success')); ?>');
        <?php endif; ?>
        <?php if(session('error')): ?>
            toastr.error('<?php echo e(session('error')); ?>');
        <?php endif; ?>
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects-new\concord-laravel\resources\views/supervisor/home.blade.php ENDPATH**/ ?>