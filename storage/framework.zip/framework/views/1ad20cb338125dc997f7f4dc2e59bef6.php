<?php $__env->startSection('title', 'Money Request'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Money Request (<?php echo e($moneyRequest->id); ?>)</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <!-- <div class="card-header">
            <h3 class="card-title">Request from Project: <?php echo e($moneyRequest->project->name); ?></h3>
        </div> -->
        <div class="card-body">
            <table class="table table-bordered" id="req-table">
                <thead>
                    <tr>
                        <th>Project Site Name</th>
                        <th>Request Number</th>
                        <th>Payment Type</th>
                        <th>Date</th>
                        <th>Money Requested by</th>
                        <th>Pending Expense Bill/Challan Amount(this project)</th>
                        <th>Pending Expense Bill/Challan Amount(TOTAL)</th>
                        <th>Amount</th>
                        
                        <!-- <th>Balance for this Project</th> -->
                        <?php if(Auth::user()->hasRole('manager')): ?>
                            <th>Total Balance</th>
                        <?php endif; ?>
                        <th>Status</th>
                        <?php if(!empty($moneyRequest->manager_status)): ?>
                            <th>Manager Status</th>
                            <th>Manager</th>
                            <th>Manager Status Updated At</th>
                        <?php endif; ?>
                        <?php if(!empty($moneyRequest->admin_status)): ?>
                            <th>Owner Status</th>
                            <th>Owner</th>
                            <th>Owner Status Updated At</th> 
                        <?php endif; ?>
                        <th>Note</th>
                        <?php if(!empty($moneyRequest->manager_note)): ?>
                            <th>Manager Note</th>
                        <?php endif; ?>
                        <?php if(!empty($moneyRequest->admin_note)): ?>
                            <th>Owner Note</th>
                        <?php endif; ?>
                        <?php if(!empty($moneyRequest->amanager_note)): ?>
                            <th>Account Manager Note</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($moneyRequest->project->name); ?></td>
                        <td><?php echo e($moneyRequest->id); ?></td>
                        <td><?php echo e($moneyRequest->payment_type); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($moneyRequest->date)->format('h:i A d/m/Y')); ?></td>
                        <td><?php echo e($moneyRequest->user->name); ?></td>
                        <td>₹<?php echo e(formatIndianCurrency($projectbalance)); ?></td>
                        <td>
                            ₹<?php echo e(Auth::user()->hasRole('manager') || Auth::user()->hasRole('supervisor') ? formatIndianCurrency($overallBalance) : formatIndianCurrency($overallBalance1)); ?>

                        </td>
                        <td>₹<?php echo e(formatIndianCurrency($moneyRequest->amount)); ?></td>
                        
                        <!-- <td>₹<?php echo e(formatIndianCurrency($moneyRequest->project->budget)); ?></td> -->
                        <?php if(Auth::user()->hasRole('manager')): ?>
                            <td>₹<?php echo e(formatIndianCurrency($projectbalance)); ?></td>
                        <?php endif; ?>
                        <td>
                            <?php
                                $statusClass = '';
                                if ($moneyRequest->status === 'approved') {
                                    $statusClass = 'bg-success text-white';
                                } elseif ($moneyRequest->status === 'rejected') {
                                    $statusClass = 'bg-danger text-white';
                                }
                            ?>
                            <span class="label <?php echo e($statusClass); ?>"><?php echo e(ucfirst($moneyRequest->status)); ?></span>
                        </td>
                        <?php if(!empty($moneyRequest->manager_status)): ?>
                            <td>
                                <?php
                                    $statusClass = '';
                                    if ($moneyRequest->manager_status === 'approved') {
                                        $statusClass = 'bg-success text-white';
                                    } elseif ($moneyRequest->manager_status === 'rejected') {
                                        $statusClass = 'bg-danger text-white';
                                    }
                                ?>
                                <span class="label <?php echo e($statusClass); ?>"><?php echo e(ucfirst($moneyRequest->manager_status)); ?></span>
                            </td>
                            <td><?php echo e($moneyRequest->manager ? $moneyRequest->manager->name : 'N/A'); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($moneyRequest->manager_status_updated_at)->format('h:i A d/m/Y')); ?></td>
                        <?php endif; ?>
                        <?php if(!empty($moneyRequest->admin_status)): ?>
                            <td>
                                <?php
                                    $statusClass = '';
                                    if ($moneyRequest->admin_status === 'approved') {
                                        $statusClass = 'bg-success text-white';
                                    } elseif ($moneyRequest->admin_status === 'rejected') {
                                        $statusClass = 'bg-danger text-white';
                                    }
                                ?>
                                <span class="label <?php echo e($statusClass); ?>"><?php echo e(ucfirst($moneyRequest->admin_status)); ?></span>
                            </td>
                            <td><?php echo e($moneyRequest->admin ? $moneyRequest->admin->name : 'N/A'); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($moneyRequest->admin_status_updated_at)->format('h:i A d/m/Y')); ?></td>
                        <?php endif; ?>
                        <td><?php echo e($moneyRequest->note); ?></td>
                        <?php if(!empty($moneyRequest->manager_note)): ?>
                            <td><?php echo e($moneyRequest->manager_note); ?></td>
                        <?php endif; ?>
                        <?php if(!empty($moneyRequest->admin_note)): ?>
                            <td><?php echo e($moneyRequest->admin_note); ?></td>
                        <?php endif; ?>
                        <?php if(!empty($moneyRequest->amanager_note)): ?>
                            <td><?php echo e($moneyRequest->amanager_note); ?></td>
                        <?php endif; ?>
                    </tr>
                </tbody>
            </table>

            <?php if($moneyRequest->manager_status == '' && Auth::user()->hasRole('manager') && $moneyRequest->user_id != Auth::id()): ?>
                <form action="<?php echo e(route('money-requests.updateStatus', $moneyRequest->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group">
                        <label for="note">Note:</label>
                        <textarea name="note" id="note" class="form-control"><?php echo e(old('note')); ?></textarea>
                    </div>
                    <button type="submit" name="status" value="approved" class="btn btn-success mb-2 full-width-approve">Approve</button>
                    <button type="submit" name="status" value="rejected" class="btn btn-danger mb-2 full-width-cancel">Reject</button>
                </form>
            <?php elseif($moneyRequest->manager_status == 'approved' && Auth::user()->hasRole('owner') && is_null($moneyRequest->admin_status)): ?>
                <form action="<?php echo e(route('money-requests.updateStatus', $moneyRequest->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group">
                        <label for="admin_note">Owner Note:</label>
                        <textarea name="admin_note" id="admin_note" class="form-control"><?php echo e(old('admin_note')); ?></textarea>
                    </div>
                    <button type="submit" name="status" value="approved" class="btn btn-success d-block mb-2 full-width-approve">Approve</button>
                    <button type="submit" name="status" value="rejected" class="btn btn-danger d-block mb-2 full-width-cancel">Reject</button>
                </form>
            <?php elseif($moneyRequest->admin_status == 'approved' && $moneyRequest->amanager_status == '' && Auth::user()->hasRole('account manager')): ?>
                <form action="<?php echo e(route('money-requests.updateStatus', $moneyRequest->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group">
                        <label for="amanager_note">Notes from Accountant:</label>
                        <textarea name="amanager_note" id="amanager_note" class="form-control"><?php echo e(old('accountant_note')); ?></textarea>
                    </div>
                    <button type="submit" name="amanager_status" value="approved" class="btn btn-success d-block mb-2 full-width-approve">Payment DONE</button>
                </form>
            <?php endif; ?>
            
            <?php if(request()->query('source') === 'store'): ?>
            <button type="button" class="btn btn-secondary mt-3 full-width-approve" 
                onclick="window.location.href='<?php echo e(route('supervisor.moneyRequests.pending')); ?>';">Close
            </button>
            <?php else: ?>
                <button type="button" class="btn btn-secondary mt-3 full-width-approve" onclick="window.history.back();">Close</button>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        // Toastr configuration
        var table = $('#req-table').DataTable({
                responsive: {
                    details: {
                        display: $.fn.dataTable.Responsive.display.childRowImmediate,
                        type: 'inline',
                        }
                },
                paging: false,
                searching: false,
                info: false,
                ordering: false,
                autoWidth: false,
                
        });

        table.rows().every(function(rowIdx, tableLoop, rowLoop) {
                var row = this;
                if (!row.child.isShown()) {
                    row.child.show();
                    $(row.node()).addClass('shown');  
                }
            });

        toastr.options = {
            positionClass: 'toast-bottom-right',
            hideDuration: 5000,
            timeOut: 5000,
            extendedTimeOut: 1000,
        };

        <?php if(session('success')): ?>
            toastr.success('<?php echo e(session('success')); ?>');
        <?php endif; ?>
        <?php if(session('error')): ?>
            toastr.error('<?php echo e(session('error')); ?>');
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects-new\concord-laravel\resources\views/projects/approve.blade.php ENDPATH**/ ?>