<?php $__env->startSection('title', 'View Project'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Project Details</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e($project->name); ?></h3>
        </div>
        <div class="card-body">
            <table id="example-table" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Project Site Name</th>
                        <th>Location</th>
                        <th>Project Start Date</th>
                        <th>Project Status</th>
                        <th>List of Staff Members Assigned</th>
                        <th>Project Budget</th>
                        <?php if(Auth::user()->hasRole('manager') || Auth::user()->hasRole('owner')  || Auth::user()->hasRole('account manager')): ?>
                        <th>Total Money In</th>
                        <th>Total Money Out</th>
                        <th>Expense Bill Pending</th>
                        <?php endif; ?>
                        <th>Note</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($project->name); ?></td>
                        <td><?php echo e($project->location); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($project->start_date)->format('h:i A d/m/Y')); ?></td>
                        <td>
                            <?php
                                $statusClass = '';
                                if ($project->status === 'approved') {
                                    $statusClass = 'bg-success text-white';
                                } elseif ($project->status === 'rejected') {
                                    $statusClass = 'bg-danger text-white';
                                }
                            ?>
                            <span class="label <?php echo e($statusClass); ?>"><?php echo e(ucfirst($project->status)); ?></span>
                        </td>
                        <td>
                            <ul>
                                <?php $__currentLoopData = $project->supervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($supervisor->name); ?>: <?php echo e($supervisor->mobile_no); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                        <td>₹<?php echo e(formatIndianCurrency($project->budget)); ?></td>
                        <?php if(Auth::user()->hasRole('manager') || Auth::user()->hasRole('owner')  || Auth::user()->hasRole('account manager')): ?>
                        <td>₹<?php echo e(formatIndianCurrency($approvedRequestsProjectwise)); ?></td>
                        <td>₹<?php echo e(formatIndianCurrency($approvedChallansProjectwise)); ?></td>
                        <td>₹<?php echo e(formatIndianCurrency($pendingChallansProjectwise)); ?></td>
                        <?php endif; ?>
                        <td><?php echo e($project->note); ?></td>
                    </tr>
                </tbody>
            </table>

            
            <!-- <div class="form-group">
                <label>Note:</label>
                <p><?php echo e($project->note); ?></p>
            </div> -->
            <?php if(Auth::user()->hasRole('account manager') || Auth::user()->hasRole('owner') || Auth::user()->hasRole('manager')): ?>
                <!-- List of Pending Expense Bill/Challan as Cards -->
                <div class="form-group">
                    <label>Expense Bill/Challan Pending List</label>
                    <?php if($pendingChallans->isEmpty()): ?>
                        <p>No pending expense bills or challans found.</p>
                    <?php else: ?>
                        <table id="expense-table" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Supervisor Name</th>
                                    <th>Pending Expense Bill/Challan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pendingChallans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($challan->user->name); ?></td>
                                        <td>₹<?php echo e(formatIndianCurrency($challan->amount)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <!-- List of Money In Transactions as Cards -->
                <div class="form-group">
                    <label>Money In Transactions:</label>
                    <?php if($moneyInTransactions->isEmpty()): ?>
                        <p>No transactions found.</p>
                    <?php else: ?>
                        <table id="money-in-table" class="table table-bordered money-table">
                            <thead>
                                <tr>
                                    <th>Transaction ID</th>
                                    <th>Type</th>
                                    <th>From</th>
                                    <th>To</th>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $moneyInTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($transaction->transaction_id); ?></td>
                                        <td><?php echo e($transaction->payment_type); ?></td>
                                        <td><?php echo e($transaction->from); ?></td>
                                        <td><?php echo e($transaction->to); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($transaction->payment_datetime)->format('h:i A d/m/Y')); ?></td>
                                        <td>₹<?php echo e(formatIndianCurrency($transaction->amount)); ?></td>
                                        <td><?php echo e($transaction->notes ?? 'N/A'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <!-- List of Money Out Transactions as Cards -->
                <div class="form-group">
                    <label>Money Out Transactions:</label>
                    <?php if($moneyOutTransactions->isEmpty()): ?>
                        <p>No Money Out transactions found.</p>
                    <?php else: ?>
                        <table id="money-out-table" class="table table-bordered money-table">
                            <thead>
                                <tr>
                                    <th>Transaction ID</th>
                                    <th>Type</th>
                                    <th>From</th>
                                    <th>To</th>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $moneyOutTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($transaction->transaction_id); ?></td>
                                        <td><?php echo e($transaction->payment_type); ?></td>
                                        <td><?php echo e($transaction->from); ?></td>
                                        <td><?php echo e($transaction->to); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($transaction->payment_date)->format('h:i A d/m/Y')); ?></td>
                                        <td>₹<?php echo e(formatIndianCurrency($transaction->amount)); ?></td>
                                        <td><?php echo e($transaction->notes ?? 'N/A'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <!-- List of Approved Money Requests -->
                    <div class="form-group">
                        <label>Approved Money Requests:</label>
                        <?php if($approvedMoneyRequests->isEmpty()): ?>
                            <p>No approved money requests found.</p>
                        <?php else: ?>
                            <table class="table table-bordered money-table" id="approved-money-requests-table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Request ID</th>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Notes</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $approvedMoneyRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($request->user->name); ?></td>
                                            <td><?php echo e($request->id); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($request->date)->format('h:i A d/m/Y')); ?></td>
                                            <td>₹<?php echo e(formatIndianCurrency($request->amount)); ?></td>
                                            
                                            <td><?php echo e($request->note ?? 'N/A'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>


                <!-- List of Approved Challans as Cards -->
                <div class="form-group">
                    <label>Expense Bill/Challan Transactions:</label>
                    <?php if($approvedChallans->isEmpty()): ?>
                        <p>No approved expense bills or challans found.</p>
                    <?php else: ?>
                        <table id="expense-challan-table" class="table table-bordered money-table">
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>From</th>
                                    <th>Date</th>
                                    <th>Amount</th>
                                    <th>Notes</th>
                                    <th>File</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $approvedChallans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($challan->payment_type); ?></td>
                                        <td><?php echo e($challan->user->name); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($challan->bill_date)->format('d/m/Y')); ?></td>
                                        <td>₹<?php echo e(formatIndianCurrency($challan->amount)); ?></td>
                                        <td><?php echo e($challan->note ?? 'N/A'); ?></td>
                                        <td>
                                            <?php if($challan->upload_image): ?>
                                                <?php $__currentLoopData = json_decode($challan->upload_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="file-entry">
                                                        <span><?php echo e(strlen(basename($file)) > 5 ? substr(basename($file), 0, 5) . '...' : basename($file)); ?></span><br>
                                                        <button type="button" class="btn btn-primary btn-sm create-btn m-1" data-toggle="modal" data-target="#viewFileModal" data-file="<?php echo e(asset('storage/' . $file)); ?>">View</button>
                                                        <a href="<?php echo e(asset('storage/' . $file)); ?>" class="btn btn-secondary btn-sm create-btn m-1" download>Download</a>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
                <button type="button" class="btn btn-secondary mt-3 full-width-view" onclick="window.history.back();">Close</button>
                <!-- Modal -->
                <div class="modal fade" id="viewFileModal" tabindex="-1" role="dialog" aria-labelledby="viewFileModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="viewFileModalLabel">View File</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <iframe id="fileViewer" style="width: 100%; height: 500px;" frameborder="0"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end Modal -->  
            <?php endif; ?>
            <!-- <div class="form-group">
                <label>Money Requests:</label>
                <div id="table-view">
                    <table class="table table-bordered" id="money-requests-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Payment Type</th>
                                <th>Status</th>
                                <th>Note</th>
                                <?php if(Auth::user()->hasRole('manager') || Auth::user()->hasRole('owner') || Auth::user()->hasRole('account manager')): ?>
                                    <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $moneyRequests = $project->moneyRequests->sortByDesc('created_at');
                                if (Auth::user()->hasRole('account manager')) {
                                    $moneyRequests = $moneyRequests->filter(function($request) {
                                        return $request->admin_status === 'approved';
                                    });
                                }
                                if (Auth::user()->hasRole('owner')) {
                                    $moneyRequests = $moneyRequests->filter(function($request) {
                                        return $request->manager_status === 'approved';
                                    });
                                }
                            ?>
                            <?php $__currentLoopData = $moneyRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($request->date)->format('h:i A d/m/Y')); ?></td>
                                    <td>₹<?php echo e(formatIndianCurrency($request->amount)); ?></td>
                                    <td><?php echo e($request->payment_type); ?></td>
                                    <td>
                                        <?php
                                            $statusClass = '';
                                            if ($request->status === 'approved') {
                                                $statusClass = 'bg-success text-white';
                                            } elseif ($request->status === 'rejected') {
                                                $statusClass = 'bg-danger text-white';
                                            }
                                        ?>
                                        <span class="label <?php echo e($statusClass); ?>"><?php echo e(ucfirst($request->status)); ?></span>
                                    </td>
                                    <td><?php echo e($request->note); ?></td>
                                    <?php if((Auth::user()->hasRole('manager') && $request->status == 'pending') || Auth::user()->hasRole('owner') || Auth::user()->hasRole('account manager') || Auth::user()->hasRole('supervisor')): ?>
                                        <td>
                                            <a href="<?php echo e(route('projects.approve', $request->id)); ?>" class="btn btn-primary btn-sm full-width-view">View</a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div id="list-view" class="d-none">
                    <ul class="list-group" id="money-requests-list"></ul>
                </div>
            </div> -->

            <?php if(Auth::user()->hasAnyRole(['supervisor'])): ?>
                <div class="form-group">
                    <button type="button" class="btn btn-success full-width-approve" data-toggle="modal" data-target="#moneyRequestModal">
                        Create New Money Request
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if(Auth::user()->hasAnyRole(['manager', 'supervisor'])): ?>
        <!-- Money Request Modal -->
        <div class="modal fade" id="moneyRequestModal" tabindex="-1" role="dialog" aria-labelledby="moneyRequestModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="<?php echo e(route('money-requests.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="moneyRequestModalLabel">Create New Money Request</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="project_id">Project</label>
                                <select name="project_id" id="project_id" class="form-control" required>
                                    <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="date">Date</label>
                                <input type="date" name="date" id="date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="amount">Amount</label>
                                <input type="number" name="amount" id="amount" class="form-control" step="0.01" required>
                            </div>
                            <div class="form-group">
                                <label for="payment_type">Payment Type</label>
                                <select name="payment_type" id="payment_type" class="form-control" required>
                                    <option value="Cash">Cash</option>
                                    <option value="Cheque">Cheque</option>
                                    <option value="Bank Transfer">Bank Transfer</option>
                                    <option value="UPI">UPI</option>
                                    <option value="DD(Demand Draft)">DD(Demand Draft)</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="note">Note</label>
                                <textarea name="note" id="note" class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary full-width-approve">Save</button>
                            <button type="button" class="btn btn-secondary full-width-cancel" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script>
    $(document).ready(function() {
        $('#viewFileModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); 
        var fileUrl = button.data('file'); 
        var modal = $(this);
        modal.find('.modal-body #fileViewer').attr('src', fileUrl);
    });
    var exampleTable = $('#example-table').DataTable({
        responsive: {
            details: {
                display: $.fn.dataTable.Responsive.display.childRowImmediate,
                type: 'inline',
            }
        },
        paging: false,
        searching: false,
        info: false,
        ordering: false,
        autoWidth: false,
    });

    exampleTable.rows().every(function(rowIdx, tableLoop, rowLoop) {
        var row = this;
        if (!row.child.isShown()) {
            row.child.show();
            $(row.node()).addClass('shown');  
        }
    });


    var moneyInTable = $('.money-table').DataTable({
        responsive: {
            details: {
                display: $.fn.dataTable.Responsive.display.childRowImmediate,
                type: 'inline',
            }
        },
        paging: true,
        // searching: false,
        // info: false,
        // ordering: false,
        autoWidth: false,
        lengthChange: true,
    });
    // Ensure all rows are shown in responsive mode
    moneyInTable.rows().every(function(rowIdx, tableLoop, rowLoop) {
        var row = this;
        if (!row.child.isShown()) {
            row.child.show();
            $(row.node()).addClass('shown');  
        }
    });

    $('#money-details-table').DataTable({
        responsive: {
            details: {
                display: $.fn.dataTable.Responsive.display.childRowImmediate,
                type: 'inline',
            }
        },
        paging: true,
        // searching: false,
        // info: false,
        // ordering: false,
        autoWidth: false,
    });

    $('#expense-table').DataTable({
        responsive: {
            details: {
                display: $.fn.dataTable.Responsive.display.childRowImmediate,
                type: 'inline',
            }
        },
        paging: true,
        // searching: false,
        // info: false,
        // ordering: false,
        autoWidth: false,
    });

    $('#money-requests-table').DataTable({
        order: [[1, 'desc']],
        responsive: true,
        autoWidth: false,
    });

    toastr.options = {
        positionClass: 'toast-bottom-right',
        hideDuration: 5000,
        timeOut: 5000,
        extendedTimeOut: 1000,
    };

    <?php if(session('success')): ?>
        toastr.success('<?php echo e(session('success')); ?>');
    <?php endif; ?>
    <?php if(session('error')): ?>
        toastr.error('<?php echo e(session('error')); ?>');
    <?php endif; ?>
    
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects-new\concord-laravel\resources\views/projects/show.blade.php ENDPATH**/ ?>