<?php $__env->startSection('title', 'Challan Details'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Bill/Challan Details (<?php echo e($challan->id); ?>)</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-body">
            <!-- <div id="table-view" class="d-none d-md-block">
                <table class="table table-bordered">
                    <tr>
                        <th>Project Site Name</th>
                        <td><?php echo e($challan->project->name); ?></td>
                    </tr>
                    <tr>
                        <th>Request Number</th>
                        <td><?php echo e($challan->id); ?></td>
                    </tr>
                    <tr>
                        <th>Payment Type</th>
                        <td><?php echo e($challan->payment_type); ?></td>
                    </tr>
                    <tr>
                        <th>Date</th>
                        <td><?php echo e(\Carbon\Carbon::parse($challan->bill_date)->format('d F Y')); ?></td>
                    </tr>
                    <tr>
                        <th>Expense Bill/Challan Uploaded by</th>
                        <td><?php echo e($challan->user->name); ?></td>
                    </tr>
                    <tr>
                        <th>Pending Expense Bill/Challan Amount (this project)</th>
                        <td><?php echo e($challan->pending_amount); ?></td>
                    </tr>
                    <tr>
                        <th>Pending Expense Bill/Challan Amount (TOTAL)</th>
                        <td><?php echo e($challan->total_pending_amount); ?></td>
                    </tr>
                    <tr>
                        <th>Bill/Challan Verification Status</th>
                        <td>
                            <?php
                                $statusClass = '';
                                if ($challan->status === 'approved') {
                                    $statusClass = 'bg-success text-white';
                                } elseif ($challan->status === 'rejected') {
                                    $statusClass = 'bg-danger text-white';
                                }
                            ?>
                            <p ><span class="<?php echo e($statusClass); ?>"><?php echo e(ucfirst($challan->status)); ?></span></p>
                        </td>
                    </tr>
                    <tr>
                        <th>Amount</th>
                        <td><?php echo e($challan->amount); ?></td>
                    </tr>
                    <tr>
                        <th>Notes</th>
                        <td><?php echo e($challan->note); ?></td>
                    </tr>
                    <tr>
                        <th>Uploaded Files</th>
                        <td>
                            <?php if($challan->upload_image): ?>
                                <?php $__currentLoopData = json_decode($challan->upload_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span><?php echo e(basename($file)); ?></span>
                                        <div>
                                            <button type="button" class="btn btn-primary btn-sm create-btn" data-toggle="modal" data-target="#viewFileModal" data-file="<?php echo e(asset('storage/' . $file)); ?>">View</button>
                                            <a href="<?php echo e(asset('storage/' . $file)); ?>" class="btn btn-secondary btn-sm create-btn" download>Download</a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>

                    </tr>
                </table>
            </div> -->
            <div id="list-view1">
                
                <table class="table table-bordered" id="challan-details-table">
                    <thead>
                        <tr>
                            <th>Project Site Name</th>
                            <th>Bill/Challan Number</th>
                            <th>Payment Type</th>
                            <th>Date</th>
                            <th>Expense Bill/Challan Uploaded by</th>
                            <th>Pending Expense Bill/Challan Amount (this project)</th>
                            <th>Pending Expense Bill/Challan Amount (TOTAL)</th>
                            <th>Bill/Challan Verification Status</th>
                            <th>Amount</th>
                            <th>Notes</th>
                            <th>Files</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($challan->project->name); ?></td>
                            <td><?php echo e($challan->id); ?></td>
                            <td><?php echo e($challan->payment_type); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($challan->bill_date)->format('d F Y')); ?></td>
                            <td><?php echo e($challan->user->name); ?></td>
                            <td><?php echo e($challan->pending_amount); ?></td>
                            <td><?php echo e($challan->total_pending_amount); ?></td>
                            <td>
                                <span class="badge <?php echo e($statusClass); ?>"><?php echo e(ucfirst($challan->status)); ?></span>
                            </td>
                            <td><?php echo e($challan->amount); ?></td>
                            <td><?php echo e($challan->note); ?></td>
                            <td>
                                <?php if($challan->upload_image): ?>
                                    <?php $__currentLoopData = json_decode($challan->upload_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="file-entry">
                                            <span><?php echo e(strlen(basename($file)) > 5 ? substr(basename($file), 0, 5) . '...' : basename($file)); ?></span><br>
                                            <button type="button" class="btn btn-primary btn-sm create-btn m-1" data-toggle="modal" data-target="#viewFileModal" data-file="<?php echo e(asset('storage/' . $file)); ?>">View</button>
                                            <a href="<?php echo e(asset('storage/' . $file)); ?>" class="btn btn-secondary btn-sm create-btn m-1" download>Download</a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>

            </div>
            <?php if(Auth::user()->hasRole('manager')): ?> 
                    <button type="button" class="btn btn-secondary mt-3 full-width-view" onclick="window.history.back();">Close</button>
            <?php endif; ?>

            
            <!-- Modal -->
            <div class="modal fade" id="viewFileModal" tabindex="-1" role="dialog" aria-labelledby="viewFileModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="viewFileModalLabel">View File</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <iframe id="fileViewer" style="width: 100%; height: 500px;" frameborder="0"></iframe>
                        </div>
                    </div>
                </div>
            </div>
             <!-- end Modal -->                   
            <?php if(Auth::user()->hasRole('account manager') && $challan->status == 'pending'): ?>
                <form action="<?php echo e(route('challans.updateStatus', $challan->id)); ?>" method="POST" class="mt-3">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group">
                        <label for="note">Notes</label>
                        <textarea name="note" id="note" class="form-control" rows="3"><?php echo e(old('note')); ?></textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" name="status" value="approved" class="btn btn-success full-width-approve">Approve</button>
                        <button type="submit" name="status" value="rejected" class="btn btn-danger full-width-cancel">Reject</button>
                    </div>
                </form>
            <?php else: ?>
                <!-- <div class="form-group">
                    <label for="note">Notes</label>
                    <p><?php echo e($challan->note); ?></p>
                </div> -->
            <?php endif; ?>
            <?php if(Auth::user()->hasRole('account manager')): ?> 
                    <button type="button" class="btn btn-secondary mt-3 full-width-view" onclick="window.history.back();">Close</button>
            <?php endif; ?>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
            var table = $('#challan-details-table').DataTable({
                responsive: {
                    details: {
                        display: $.fn.dataTable.Responsive.display.childRowImmediate,
                        type: 'inline',
                        }
                },
                autoWidth: false,
                paging: false,
                searching: false,
                info: false,
                ordering: false,
                order: [[0, 'desc']],
        });

        table.rows().every(function(rowIdx, tableLoop, rowLoop) {
                var row = this;
                if (!row.child.isShown()) {
                    row.child.show();
                    $(row.node()).addClass('shown');  
                }
            });
    });
    $('#viewFileModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Button that triggered the modal
        var fileUrl = button.data('file'); // Extract info from data-* attributes
        var modal = $(this);
        modal.find('.modal-body #fileViewer').attr('src', fileUrl);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects-new\concord-laravel\resources\views/challans/show.blade.php ENDPATH**/ ?>