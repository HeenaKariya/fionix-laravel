<?php $__env->startSection('title', 'Add Bill/ Challan'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Add Bill/Challan</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('projects.challans.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="project_id">Project Site Name</label>
                    <select name="project_id" id="project_id" class="form-control" required>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($proj->id); ?>" <?php echo e(old('project_id') == $proj->id ? 'selected' : ''); ?>>
                                <?php echo e($proj->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('project_id')): ?>
                        <span class="text-danger"><?php echo e($errors->first('project_id')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="bill_date">Bill/Challan Date</label>
                    <input type="date" name="bill_date" class="form-control" value="<?php echo e(old('bill_date', date('Y-m-d'))); ?>" required>
                    <?php if($errors->has('bill_date')): ?>
                        <span class="text-danger"><?php echo e($errors->first('bill_date')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="amount">Amount</label>
                    <input type="number" name="amount" class="form-control" value="<?php echo e(old('amount')); ?>" required>
                    <?php if($errors->has('amount')): ?>
                        <span class="text-danger"><?php echo e($errors->first('amount')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="payment_type">Payment Type</label>
                    <select name="payment_type" id="payment_type" class="form-control" required>
                        <option value="Cash" <?php echo e(old('payment_type') == 'Cash' ? 'selected' : ''); ?>>Cash</option>
                        <option value="Cheque" <?php echo e(old('payment_type') == 'Cheque' ? 'selected' : ''); ?>>Cheque</option>
                        <option value="Bank Transfer" <?php echo e(old('payment_type') == 'Bank Transfer' ? 'selected' : ''); ?>>Bank Transfer</option>
                        <option value="UPI" <?php echo e(old('payment_type') == 'UPI' ? 'selected' : ''); ?>>UPI</option>
                        <option value="DD(Demand Draft)" <?php echo e(old('payment_type') == 'DD(Demand Draft)' ? 'selected' : ''); ?>>DD(Demand Draft)</option>
                    </select>
                    <?php if($errors->has('payment_type')): ?>
                        <span class="text-danger"><?php echo e($errors->first('payment_type')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="expense_category">Expense Category</label>
                    <select name="expense_category" class="form-control" required>
                        <option value="Labor Charges" <?php echo e(old('expense_category') == 'Labor Charges' ? 'selected' : ''); ?>>Labor Charges</option>
                        <option value="Advertising" <?php echo e(old('expense_category') == 'Advertising' ? 'selected' : ''); ?>>Advertising</option>
                        <option value="Insurance" <?php echo e(old('expense_category') == 'Insurance' ? 'selected' : ''); ?>>Insurance</option>
                        <option value="Taxes" <?php echo e(old('expense_category') == 'Taxes' ? 'selected' : ''); ?>>Taxes</option>
                        <option value="Travel Expense" <?php echo e(old('expense_category') == 'Travel Expense' ? 'selected' : ''); ?>>Travel Expense</option>
                        <option value="Vehicle Expense" <?php echo e(old('expense_category') == 'Vehicle Expense' ? 'selected' : ''); ?>>Vehicle Expense</option>
                        <option value="Lease Payments" <?php echo e(old('expense_category') == 'Lease Payments' ? 'selected' : ''); ?>>Lease Payments</option>
                        <option value="Equipment" <?php echo e(old('expense_category') == 'Equipment' ? 'selected' : ''); ?>>Equipment</option>
                        <option value="Marketing Expense" <?php echo e(old('expense_category') == 'Marketing Expense' ? 'selected' : ''); ?>>Marketing Expense</option>
                        <option value="Contract Labor" <?php echo e(old('expense_category') == 'Contract Labor' ? 'selected' : ''); ?>>Contract Labor</option>
                        <option value="Health Insurance Deduction" <?php echo e(old('expense_category') == 'Health Insurance Deduction' ? 'selected' : ''); ?>>Health Insurance Deduction</option>
                        <option value="Materials" <?php echo e(old('expense_category') == 'Materials' ? 'selected' : ''); ?>>Materials</option>
                        <option value="Utilities" <?php echo e(old('expense_category') == 'Utilities' ? 'selected' : ''); ?>>Utilities</option>
                        <option value="Cost of sales" <?php echo e(old('expense_category') == 'Cost of sales' ? 'selected' : ''); ?>>Cost of sales</option>
                        <option value="Office expenses" <?php echo e(old('expense_category') == 'Office expenses' ? 'selected' : ''); ?>>Office expenses</option>
                        <option value="Assets" <?php echo e(old('expense_category') == 'Assets' ? 'selected' : ''); ?>>Assets</option>
                    </select>
                    <?php if($errors->has('expense_category')): ?>
                        <span class="text-danger"><?php echo e($errors->first('expense_category')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="upload_image">Upload Image/Document</label>
                    <input type="file" name="upload_image[]" class="form-control" multiple required>
                    <?php if($errors->has('upload_image.*')): ?>
                        <span class="text-danger"><?php echo e($errors->first('upload_image.*')); ?></span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="note">Note</label>
                    <textarea name="note" class="form-control"><?php echo e(old('note')); ?></textarea>
                    <?php if($errors->has('note')): ?>
                        <span class="text-danger"><?php echo e($errors->first('note')); ?></span>
                    <?php endif; ?>
                </div>

                <button type="submit" class="btn btn-primary full-width-approve">Add Bill/Challan</button>
                <?php if(Auth::user()->hasRole('supervisor')): ?>
                    <a href="<?php echo e(route('supervisor.dashboard')); ?>" class="btn btn-warning full-width-cancel">Cancel</a>
                <?php endif; ?>
                <?php if(Auth::user()->hasRole('manager')): ?>
                    <button type="button" class="btn btn-secondary mt-3 full-width-view" onclick="window.location='<?php echo e(route('manager.dashboard')); ?>'">Cancel</button>
                <?php endif; ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects-new\concord-laravel\resources\views/challans/create.blade.php ENDPATH**/ ?>